USE Com5600G08
GO

---------------------------------
		/*TESTING*/
---------------------------------
-- TIPO_DOCUMENTO LOTE

SELECT TOP 20 * FROM gestion.Tipo_Documento;

------------------ ALTAS ------------------

-- ID nulo
EXEC gestion.sp_alta_Tipo_Documento @id = NULL, @descripcion = 'Documento Prueba';

-- ID duplicado
EXEC gestion.sp_alta_Tipo_Documento @id = 'DNI', @descripcion = 'Duplicado';


-- Caso exitoso -- ejecutar despues de eliminarlo
EXEC gestion.sp_alta_Tipo_Documento @id = 'CI', @descripcion = 'C�dula de Identidad';

------------------ MODIFICACIONES ------------------

-- No existe
EXEC gestion.sp_modificar_Tipo_Documento @id = 'ZZZ', @descripcion = 'Inexistente';
-- Esperado: Error "Tipo_Documento no encontrado."

-- Caso exitoso
EXEC gestion.sp_modificar_Tipo_Documento @id = 'CI', @descripcion = 'Documento modificado';
EXEC gestion.sp_modificar_Tipo_Documento @id = 'CI', @descripcion = 'C�dula de Identidad';
------------------ BAJAS ------------------

-- Tiene personas asociadas
EXEC gestion.sp_eliminar_Tipo_Documento @id = 'DNI';
-- Esperado: Error "No se puede eliminar Tipo_Documento: existen Personas asociadas."

-- No existe
EXEC gestion.sp_eliminar_Tipo_Documento @id = 'ZZZ';

-- Caso exitoso
EXEC gestion.sp_eliminar_Tipo_Documento @id = 'CI';

-- PERSONA LOTE

SELECT TOP 10 * FROM gestion.Persona --where nro_doc = 99999 ;

------------------ ALTAS ------------------

-- Nro_doc inv�lido
EXEC gestion.sp_alta_Persona @nro_doc = -1, @id_tipo_documento = 'DNI', @nombre = 'Juan', @apellido = 'P�rez';
-- Esperado: Error "Nro_doc inv�lido."

-- Tipo documento inexistente
EXEC gestion.sp_alta_Persona @nro_doc = 12345, @id_tipo_documento = 'XXX', @nombre = 'Laura', @apellido = 'G�mez';
-- Esperado: Error "Tipo de documento no existe."

-- Campos obligatorios faltantes: Nombre
EXEC gestion.sp_alta_Persona @nro_doc = 12346, @id_tipo_documento = 'DNI', @nombre = NULL, @apellido = 'G�mez';

-- Persona duplicada
EXEC gestion.sp_alta_Persona @nro_doc = 27341024, @id_tipo_documento = 'DNI', @nombre = 'DAMARIS ELIANA', @apellido = 'ZURRIAN';

-- Caso exitoso
EXEC gestion.sp_alta_Persona @nro_doc = 99999, @id_tipo_documento = 'DNI', @nombre = 'Sof�a', @apellido = 'Mart�nez', @email = 'sofia@test.com', @telefono = '1144556677';

------------------ MODIFICACIONES ------------------

-- ID inexistente
EXEC gestion.sp_modificar_Persona @id_persona = 9999, @nro_doc = 99999, @id_tipo_documento = 'DNI', @nombre = 'Cambio', @apellido = 'Inexistente';
-- Esperado: Error "Id de persona no encontrado."

-- Caso exitoso
EXEC gestion.sp_modificar_Persona @id_persona = 137, @nro_doc = 99999, @id_tipo_documento = 'DNI', @nombre = 'Sof�a', @apellido = 'Mart�nez', @email = null, @telefono ='111111111'; 


------------------ BAJAS ------------------

-- Tiene relaci�n en UF_Persona
EXEC gestion.sp_eliminar_Persona @id_persona = 2;
-- Esperado: Error "No se puede eliminar Persona: tiene relaciones en Unidad_Funcional_Persona."

-- No existe
EXEC gestion.sp_eliminar_Persona @id_persona = 9999;

-- Caso exitoso
EXEC gestion.sp_eliminar_Persona @id_persona = 137;

-- CONSORCIO LOTE

SELECT TOP 20 * FROM gestion.Consorcio;

------------------ ALTAS ------------------

-- Id nulo
EXEC gestion.sp_alta_Consorcio @id = NULL, @nombre = 'Prueba', @calle = 'Calle Falsa', @nro = 123, @localidad = 'La Matanza', @provincia = 'Buenos Aires';

-- Nombre vac�o
EXEC gestion.sp_alta_Consorcio @id = 100, @nombre = '', @calle = 'Mitre', @nro = 120, @localidad = 'San Justo', @provincia = 'Buenos Aires';

-- ID duplicado
EXEC gestion.sp_alta_Consorcio @id = 1, @nombre = 'Duplicado', @calle = 'San Mart�n', @nro = 555, @localidad = 'Haedo', @provincia = 'Buenos Aires';

-- Caso exitoso
EXEC gestion.sp_alta_Consorcio @id = 999, @nombre = 'Consorcio Prueba', @calle = 'Pringles', @nro = 200, @localidad = 'Mor�n', @provincia = 'Buenos Aires';

------------------ MODIFICACIONES ------------------

-- No existe
EXEC gestion.sp_modificar_Consorcio @id = 888, @nombre = 'Inexistente', @calle = 'Nada', @nro = 1, @localidad = 'N/A', @provincia = 'N/A';

-- Caso exitoso
EXEC gestion.sp_modificar_Consorcio @id = 999, @nombre = 'Consorcio Editado', @calle = 'Belgrano', @nro = 250, @localidad = 'Mor�n', @provincia = 'Buenos Aires';

------------------ BAJAS ------------------

-- Tiene UF asociadas
EXEC gestion.sp_eliminar_Consorcio @id = 4;

-- Tiene proveedores (se debe eliminar el proveedor que tiene asociado de la tabla gasto)
EXEC gestion.sp_eliminar_Consorcio @id = 1;

-- No existe
EXEC gestion.sp_eliminar_Consorcio @id = 888;

-- Caso exitoso
EXEC gestion.sp_eliminar_Consorcio @id = 999;

-- UNIDAD FUNCIONAL LOTE

SELECT TOP 20 * FROM gestion.Unidad_Funcional --WHERE id_consorcio = 4 and id = 31;

------------------ ALTAS ------------------

-- Id o id_consorcio nulos
EXEC gestion.sp_alta_Unidad_Funcional @id = NULL, @id_consorcio = NULL, @piso = 'PB', @depto = 'A', @porcentaje = 10, @superficie_m2 = 50, @tiene_cochera = 1, @tiene_baulera = 0;

-- Consorcio inexistente
EXEC gestion.sp_alta_Unidad_Funcional @id = 1, @id_consorcio = 9999, @piso = 'PB', @depto = 'A', @porcentaje = 10, @superficie_m2 = 50, @tiene_cochera = 1, @tiene_baulera = 0;

-- Porcentaje fuera de rango
EXEC gestion.sp_alta_Unidad_Funcional @id = 31, @id_consorcio = 1, @piso = 'PB', @depto = 'A', @porcentaje = 120, @superficie_m2 = 50, @tiene_cochera = 0, @tiene_baulera = 0;

-- Superficie <= 0
EXEC gestion.sp_alta_Unidad_Funcional @id = 31, @id_consorcio = 1, @piso = '1', @depto = 'A', @porcentaje = 10, @superficie_m2 = 0, @tiene_cochera = 0, @tiene_baulera = 0;

-- Duplicado
EXEC gestion.sp_alta_Unidad_Funcional @id = 1, @id_consorcio = 4, @piso = 'PB', @depto = 'A', @porcentaje = 10, @superficie_m2 = 50;

-- Caso exitoso
EXEC gestion.sp_alta_Unidad_Funcional @id = 31, @id_consorcio = 4, @piso = 'PB', @depto = 'Z', @porcentaje = 5, @superficie_m2 = 45, @tiene_cochera = 0, @tiene_baulera = 1;

------------------ BAJAS ------------------

-- Tiene relaciones (UF_Persona, Cuenta Bancaria, etc.)
EXEC gestion.sp_eliminar_Unidad_Funcional @id = 1, @id_consorcio = 4;

-- No existe
EXEC gestion.sp_eliminar_Unidad_Funcional @id = 999, @id_consorcio = 4;
-- Esperado: Error "Unidad_Funcional no existe."

-- Caso exitoso
EXEC gestion.sp_eliminar_Unidad_Funcional @id = 31, @id_consorcio = 4;

--TESTING LEILA
-----------UF LOTE-------------

select TOP 20* from Com5600G08.gestion.Unidad_Funcional

---------MODIFICACIONES-----------

--porcentaje fuera del rango
EXEC gestion.sp_modificar_Unidad_Funcional @id = 1,@id_consorcio = 4,@piso = NULL,
@depto = NULL,@porcentaje = 101,@superficie_m2 = 2,@tiene_cochera =1,@tiene_baulera = 0;
--UF no encontrada(ya sea por id_uf o id_consorcio)
EXEC gestion.sp_modificar_Unidad_Funcional @id = 999,@id_consorcio = 4,@piso = 'PB',
@depto = 'A',@porcentaje = 1,@superficie_m2 = 2,@tiene_cochera =1,@tiene_baulera = 0;
--superficie fuera de rango
EXEC gestion.sp_modificar_Unidad_Funcional @id = 1,@id_consorcio = 4,@piso = 'PB',
@depto = 'A',@porcentaje = 1,@superficie_m2 = -1,@tiene_cochera =1,@tiene_baulera = 0;
--piso y depto con caracteres no validos
EXEC gestion.sp_modificar_Unidad_Funcional @id = 1,@id_consorcio = 4,@piso = '/B',
@depto = 'A',@porcentaje = 1,@superficie_m2 = 2,@tiene_cochera =1,@tiene_baulera = 0;

EXEC gestion.sp_modificar_Unidad_Funcional @id = 1,@id_consorcio = 4,@piso = 'PB',
@depto = '*',@porcentaje = 1,@superficie_m2 = 2,@tiene_cochera =1,@tiene_baulera = 0;

--caso exitoso
EXEC gestion.sp_modificar_Unidad_Funcional @id = 1,@id_consorcio = 4,@piso = 'PB',
@depto = 'A',@porcentaje = 1,@superficie_m2 = 2,@tiene_cochera =1,@tiene_baulera = 0;

-----------BAJAS--------------

-- UF asociada a personas
EXEC gestion.sp_eliminar_Unidad_Funcional @id = 1, @id_consorcio = 4;
-- Esperado: Error "existen Persona-UF asociados."

-- UF no existe
EXEC gestion.sp_eliminar_Unidad_Funcional @id = 1000, @id_consorcio = 4;
-- Esperado: Error "Unidad_Funcional no existe"

-- Caso exitoso (sin relaciones): ejecutar despues de eliminar UF_Persona,cuenta_bancaria_asociada,etc
EXEC gestion.sp_eliminar_Unidad_Funcional @id = 10, @id_consorcio = 4;

----------------------------
------UF_PERSONA LOTE----------

select top 50* from Com5600G08.gestion.Unidad_Funcional_Persona

----------ALTAS---------------
-- UF inexistente
EXEC gestion.sp_alta_Unidad_Funcional_Persona 
    @id_unidad_funcional = 999, @id_consorcio_unidad_funcional = 4, 
	@id_persona = 1,
    @fecha_desde = '2023-01-01', @fecha_hasta = NULL, @es_inquilino = 0;

-- Persona inexistente
EXEC gestion.sp_alta_Unidad_Funcional_Persona 
    @id_unidad_funcional = 1, @id_consorcio_unidad_funcional = 4,
    @id_persona = 1,
    @fecha_desde = '2023-01-01', @fecha_hasta = NULL, @es_inquilino = 1;

-- Relaci�n duplicada
EXEC gestion.sp_alta_Unidad_Funcional_Persona 
    @id_unidad_funcional = 1, @id_consorcio_unidad_funcional = 4,
    @id_persona = 1,
    @fecha_desde = '2023-01-01', @fecha_hasta = NULL, @es_inquilino = 1;

-- Caso exitoso
EXEC gestion.sp_alta_Unidad_Funcional_Persona 
    @id_unidad_funcional = 1, @id_consorcio_unidad_funcional = 4,
    @id_persona = 1,
    @fecha_desde = '2024-01-01', @fecha_hasta = NULL, @es_inquilino = 0;


----------MODIFICACIONES---------------

-- No existe la relaci�n uf_persona
EXEC gestion.sp_modificar_Unidad_Funcional_Persona
    @id_unidad_funcional = 999, @id_consorcio_unidad_funcional = 4,
    @id_persona = 1,
    @fecha_desde = '2024-01-01', @fecha_hasta = NULL, @es_inquilino = 1;

-- Caso exitoso
EXEC gestion.sp_modificar_Unidad_Funcional_Persona
    @id_unidad_funcional = 1, @id_consorcio_unidad_funcional = 4,
    @id_persona = 1,
    @fecha_desde = '2024-01-01', @fecha_hasta = NULL, @es_inquilino = 1;

----------BAJAS---------------

-- Relaci�n inexistente
EXEC gestion.sp_eliminar_Unidad_Funcional_Persona 
    @id_unidad_funcional = 1, @id_consorcio_unidad_funcional = 4,
    @id_persona = 1;

-- Caso exitoso
EXEC gestion.sp_eliminar_Unidad_Funcional_Persona 
    @id_unidad_funcional = 10, @id_consorcio_unidad_funcional = 4,
    @id_persona = 1,;

-----------------------------------------
-----CUENTA BANCARIA_UF LOTES-----
select top 20* from Com5600G08.gestion.Cuenta_Bancaria_Asociada_UF where id_unidad_funcional = 1

----------ALTAS---------------
-- UF inexistente
EXEC gestion.sp_alta_Cuenta_Bancaria_Asociada_UF 
    @id_unidad_funcional = 999, @id_consorcio_unidad_funcional = 4, @cbu_cvu = '1234567890123456789012';

-- CBU/CVU inv�lido
EXEC gestion.sp_alta_Cuenta_Bancaria_Asociada_UF 
    @id_unidad_funcional = 1, @id_consorcio_unidad_funcional = 4, @cbu_cvu = '12345';

-- Duplicado
EXEC gestion.sp_alta_Cuenta_Bancaria_Asociada_UF 
    @id_unidad_funcional = 1, @id_consorcio_unidad_funcional = 4, @cbu_cvu = '2314407897385040000000';

-- Caso exitoso
EXEC gestion.sp_alta_Cuenta_Bancaria_Asociada_UF 
    @id_unidad_funcional = 1, @id_consorcio_unidad_funcional = 4, @cbu_cvu = '1111111111111111111112';

----------MODIFICACIONES---------------

-- CBU/CVU viejo inexistente
EXEC gestion.sp_modificar_Cuenta_Bancaria_Asociada_UF
    @id_unidad_funcional = 1, @id_consorcio_unidad_funcional = 4,
    @cbu_cvu_viejo = '9999999999999999999999', @cbu_cvu_nuevo = '3333333333333333333333';

-- CBU nuevo inv�lido
EXEC gestion.sp_modificar_Cuenta_Bancaria_Asociada_UF
    @id_unidad_funcional = 1, @id_consorcio_unidad_funcional = 4,
    @cbu_cvu_viejo = '2314407897385040000000', @cbu_cvu_nuevo = '12345';

-- CBU nuevo duplicado
EXEC gestion.sp_modificar_Cuenta_Bancaria_Asociada_UF
    @id_unidad_funcional = 1, @id_consorcio_unidad_funcional = 4,
    @cbu_cvu_viejo = '2314407897385040000000', @cbu_cvu_nuevo = '2314407897385040000000';

-- Caso exitoso
EXEC gestion.sp_modificar_Cuenta_Bancaria_Asociada_UF
    @id_unidad_funcional = 1, @id_consorcio_unidad_funcional = 4,
    @cbu_cvu_viejo = '1111111111111111111111', @cbu_cvu_nuevo = '9999999999999999999999';

----------BAJAS---------------

-- No existe
EXEC gestion.sp_eliminar_Cuenta_Bancaria_Asociada_UF 
    @id_unidad_funcional = 999, @id_consorcio_unidad_funcional = 4, @cbu_cvu = '9999999999999999999999';

-- Caso exitoso
EXEC gestion.sp_eliminar_Cuenta_Bancaria_Asociada_UF 
    @id_unidad_funcional = 1, @id_consorcio_unidad_funcional = 4, @cbu_cvu = '9999999999999999999999';

---------------------------------------------
-----PAGO LOTES---------
SELECT top 20* FROM Com5600G08.gestion.Pago WHERE fecha = '2025-11-01'

----------ALTAS---------------
-- CBU/CVU obligatorio
EXEC gestion.sp_alta_Pago 
     @id_pago =1801, @id_unidad_funcional = 1, @id_consorcio_unidad_funcional = 4,
    @cbu_cvu_origen = NULL , @fecha = '2025-11-01', @importe = 5;

-- Fecha nula
EXEC gestion.sp_alta_Pago 
    @id_pago =1801, @id_unidad_funcional = 1, @id_consorcio_unidad_funcional = 4,
    @cbu_cvu_origen = '1234567890123456789012', @fecha = NULL, @importe = 1000;

-- Importe <= 0
EXEC gestion.sp_alta_Pago 
    @id_pago =1801, @id_unidad_funcional = 1, @id_consorcio_unidad_funcional = 4,
    @cbu_cvu_origen = '1234567890123456789012', @fecha = '2024-01-01', @importe = 0;

--UF inexistente
EXEC gestion.sp_alta_Pago 
    @id_pago =1801, @id_unidad_funcional = 999, @id_consorcio_unidad_funcional = 4,
    @cbu_cvu_origen = '1234567890123456789012', @fecha = '2024-01-01', @importe = 1000;

--Caso exitoso
EXEC gestion.sp_alta_Pago
	@id_pago =1, @id_unidad_funcional = 1, @id_consorcio_unidad_funcional = 4,
    @cbu_cvu_origen = '1234567890123456789012', @fecha = '2025-11-01', @importe = 1;

--pago no asociado
EXEC gestion.sp_alta_Pago 
@id_pago =2, @id_unidad_funcional = null, @id_consorcio_unidad_funcional = null,
@cbu_cvu_origen = '1234567890123456789012', @fecha = '2025-11-01', @importe = 1;

----------BAJAS---------------

-- No existe
EXEC gestion.sp_eliminar_Pago @id = 99999;

--Caso exitoso
EXEC gestion.sp_eliminar_Pago @id = 1;
EXEC gestion.sp_eliminar_Pago @id = 2;

----------MODIFICACIONES---------------

EXEC gestion.sp_modificar_Pago 1, 50000;

EXEC gestion.sp_modificar_Pago 1, -30000; -- importe no valido

EXEC gestion.sp_modificar_Pago @id_pago = 2, @nuevo_importe = 85000, @nueva_fecha = '2025-11-07';

---------------------------------------------
-----TIPO GASTO LOTES---------
SELECT top 20* FROM Com5600G08.gestion.Tipo_Gasto;

----------ALTA---------------
EXEC gestion.sp_alta_Tipo_Gasto @nombre = 'VARIOS', @es_extraordinario = 0; -- caso exitoso

EXEC gestion.sp_alta_Tipo_Gasto @nombre = 'GASTOS BANCARIOS', @es_extraordinario = 1; -- gasto ya existente

----------MODIFICACIONES---------------
-- caso exitoso
EXEC gestion.sp_modificar_Tipo_Gasto @id_gasto = 1, @nuevo_nombre = 'GASTOS BANCARIOS', @nuevo_es_extraordinario = 1;

-- tipo gasto no existente
EXEC gestion.sp_modificar_Tipo_Gasto @id_gasto = 15, @nuevo_nombre = 'GASTOS BANCARIOS', @nuevo_es_extraordinario = 1;

----------BAJAS---------------
EXEC gestion.sp_eliminar_Tipo_Gasto @id_gasto = 2;

-- tipo de gasto no existente
EXEC gestion.sp_eliminar_Tipo_Gasto @id_gasto = 15;

---------------------------------------------
-----PROVEEDOR LOTES---------
SELECT top 20* FROM Com5600G08.gestion.Proveedor;

----------ALTA---------------
EXEC gestion.sp_alta_Proveedor
    @id_tipo_gasto = 1,
    @id_consorcio = 1,
    @nombre = 'Limpiezas SRL',
    @detalle = 'Servicio de limpieza mensual';

----------MODIFICACIONES---------------
EXEC gestion.sp_modificar_Proveedor
    @id_proveedor = 1,
    @nuevo_nombre = 'Limpiezas del Sur',
    @nuevo_detalle = 'Limpieza de espacios comunes y dep�sito';

----------BAJAS---------------
EXEC gestion.sp_eliminar_Proveedor
    @id_proveedor = 1;

---------------------------------------------
-----GASTO LOTES---------
SELECT top 20* FROM Com5600G08.gestion.Gasto;

----------ALTAS---------------
EXEC gestion.sp_alta_Gasto
    @id_tipo_gasto = 1,
    @id_consorcio = 1,
    @mes = 11,
    @anio = 2025,
    @nro_factura = NULL,
    @importe = 125000.00,
    @descripcion = 'Pago mensual de limpieza',
    @cuotas_totales = NULL,
    @nro_cuota = NULL;

----------MODIFICACIONES---------------
EXEC gestion.sp_modificar_Gasto
    @id_gasto = 1,
    @nuevo_importe = 140000.00,
    @nueva_descripcion = '';

----------BAJAS---------------
EXEC gestion.sp_eliminar_Gasto @id_gasto = 1;