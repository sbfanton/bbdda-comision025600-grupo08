﻿use Com5600G08
go

--reporte 1
/*Se desea analizar el flujo de caja en forma semanal. Debe presentar la recaudación por 
pagos ordinarios y extraordinarios de cada semana, el promedio en el periodo, y el 
acumulado progresivo.*/

EXEC gestion.sp_reporte_flujo_caja_semanal
    @mesInicio = 4,
    @mesFin = 6,
    @idConsorcio = 1;

EXEC gestion.sp_reporte_flujo_caja_semanal
    @mesInicio = 4,
    @mesFin = 6,
    @idConsorcio = NULL;

--reporte 2
/*Presente el total de 
recaudación por mes y departamento en formato de tabla cruzada. 
*/

EXEC gestion.sp_reporte_recaudacion_mensual_departamento
    @anio = 2025,
    @idConsorcio = 1,
    @idUnidadFuncional = null;

-- Reporte 3
/*Presente un cuadro cruzado con la recaudación total desagregada según su procedencia 
(ordinario, extraordinario, etc.) según el periodo.*/

--tiene pagos extraordinarios
EXEC  gestion.sp_reporte_recaudacion_por_procedencia
@anioInicio = 2025, @anioFin = 2025, @idConsorcio = 1;
--no tiene pagos extraordinarios
EXEC  gestion.sp_reporte_recaudacion_por_procedencia
@anioInicio = 2025, @anioFin = 2025, @idConsorcio = 2;

-- Reporte 4 en XML
--Obtenga los 5 (cinco) meses de mayores gastos y los 5 (cinco) de mayores ingresos. 

EXEC gestion.sp_reporte_mayores_ingresos_gastos_xml @id_consorcio = null, @anio_inicio = 2025, @anio_fin = 2025;

--reporte 5 en XML
/*Obtenga los 3 (tres) propietarios con mayor morosidad. Presente informacion de contacto y
DNI de los propietarios para que la administracion los pueda contactar o remitir el tramite al
estudio juridico.*/

EXEC gestion.sp_reporte_top_morosos null, 100, 0;
EXEC gestion.sp_reporte_top_morosos null, 100, 0, 33000000;
EXEC gestion.sp_reporte_top_morosos 

--luego de cifrar
EXEC gestion.sp_reporte_top_morosos @FraseClaveCargadaPorUsuario = N'QuieroMiPanDanes';

--reporte 6
/*Muestre las fechas de pagos de expensas ordinarias de cada UF y la cantidad de d�as que
pasan entre un pago y el siguiente, para el conjunto examinado.*/

EXEC gestion.sp_reporte_pagos_Ordinarios;

--generacion de expensas
EXEC gestion.sp_modelo_expensa 1,4,2025;


--luego de cifrar
EXEC gestion.sp_modelo_expensa @FraseClaveCargadaPorUsuario = N'QuieroMiPanDanes',
    @id_consorcio = 1,
    @mes = 5,
    @anio = 2025;