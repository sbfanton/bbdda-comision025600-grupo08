/*
- Materia: Bases de Datos Aplicadas

- Comisi�n: 02-5600 - Viernes Tarde

- Fecha: 7/11/2025

- Grupo: 8

- Integrantes:
Cazal, Leila Abigail - 42023980
Fanton, Sol Bel�n - 38789602
Castro, Ezequiel Alejandro - 45239803
Grance Zenteno, Lucas Rodrigo - 43406784

- Enunciado:
*** Entrega 7 -Requisitos de seguridad *** 
Asigne los roles correspondientes para poder cumplir con este requisito, seg�n el �rea a la cual pertenece.
Rol: Administrativo operativo - Acciones: Actualizaci�n de datos UF, Generaci�n de reportes (...)

Este archivo corresponde al testing del rol Administrativo operativo

*/
USE Com5600G08
GO
-- conectarse con login 'admin_operativo'

--si
EXEC gestion.sp_modificar_Unidad_Funcional @id = 1,@id_consorcio = 4,@piso = 'PB',
@depto = 'A',@porcentaje = 1,@superficie_m2 = 2,@tiene_cochera =1,@tiene_baulera = 0;


EXEC gestion.sp_importar_pagos
     @path = N'C:\Consorcios\pagos_consorcios.csv'; 
--no

EXEC gestion.sp_reporte_recaudacion_por_procedencia 
@anioInicio = 2025, @anioFin = 2025, @idConsorcio = 1;
--si

EXEC gestion.sp_reporte_mayores_ingresos_gastos_xml 
@id_consorcio = NULL, @anio_inicio = 2025, @anio_fin = 2025;
--si

EXEC gestion.sp_eliminar_Unidad_Funcional_Persona 
    @id_unidad_funcional = 10, @id_consorcio_unidad_funcional = 4,
    @id_persona = 1; 
--si

EXEC gestion.sp_reporte_top_morosos 
--si...pero
/*Este reporte usa API, por eso nos pide darle permisos de sysadmin 
pero no creemos que sea lo correcto darle acceso a toda la base de datos.*/

EXEC gestion.sp_modificar_Consorcio 
@id = 999, @nombre = 'Consorcio Editado', @calle = 'Belgrano', @nro = 250, @localidad = 'Mor�n', @provincia = 'Buenos Aires';
--no