/*
- Materia: Bases de Datos Aplicadas

- Comisi�n: 02-5600 - Viernes Tarde

- Fecha: 7/11/2025

- Grupo: 8

- Integrantes:
Cazal, Leila Abigail - 42023980
Fanton, Sol Bel�n - 38789602
Castro, Ezequiel Alejandro - 45239803
Grance Zenteno, Lucas Rodrigo - 43406784

- Enunciado:
*** Entrega 7 -Requisitos de seguridad *** 
(...)
Por otra parte, se requiere que apliquen cifrado a datos sensibles/personales incluidos en el sistema. Lea el material de la unidad 6 disponible en Miel para determinar qu� datos en su implementaci�n encajan con esa descripci�n.
El cifrado tendr�n que aplicarlo a posteriori de la realizaci�n de las funciones que manejen los datos mencionados. Por ello tendr�n que incorporar scripts de modificaci�n de estructuras de datos, modificaci�n sobre store procedures y vistas y tal vez creaci�n de triggers u otro mecanismo para implementar el cifrado. Este cambio realizado al sistema es �en un solo sentido� y se entiende que al aplicarlo no es reversible. Notar que tambi�n deber�n modificar los reportes que presenten informaci�n cifrada para que sea legible.
(...)

En este archivo se realiza el testing de cifrado de datos.

*/
USE Com5600G08
GO


EXEC gestion.sp_desencriptar_datos_cbu_cvu
@FraseClaveCargadaPorUsuario = N'QuieroMiPanDanes';

EXEC gestion.sp_desencriptar_datos_cbu_pago
@FraseClaveCargadaPorUsuario = N'QuieroMiPanDanes';

EXEC gestion.sp_desencriptar_datos_persona
@FraseClaveCargadaPorUsuario = N'QuieroMiPanDanes';

select top 10* from gestion.Cuenta_Bancaria_Asociada_UF
select top 10* from gestion.Pago
select top 10* from gestion.Persona

EXEC gestion.sp_modelo_expensa @FraseClaveCargadaPorUsuario = N'QuieroMiPanDanes',
    @id_consorcio = 1,
    @mes = 6,
    @anio = 2025;


EXEC gestion.sp_reporte_top_morosos @FraseClaveCargadaPorUsuario = N'QuieroMiPanDanes';
