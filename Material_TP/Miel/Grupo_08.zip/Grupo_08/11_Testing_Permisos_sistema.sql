/*

- Materia: Bases de Datos Aplicadas

- Comisi�n: 02-5600 - Viernes Tarde

- Fecha: 7/11/2025

- Grupo: 8

- Integrantes:
Cazal, Leila Abigail - 42023980
Fanton, Sol Bel�n - 38789602
Castro, Ezequiel Alejandro - 45239803
Grance Zenteno, Lucas Rodrigo - 43406784

- Enunciado:
*** Entrega 7 -Requisitos de seguridad *** 
Asigne los roles correspondientes para poder cumplir con este requisito, seg�n el �rea a la cual pertenece.
Rol: Sistemas - Acciones: Generaci�n de reportes  (...)

Este archivo corresponde al testing del rol Sistemas

*/
USE Com5600G08
GO

-- conectarse con login 'sistemas'

EXEC gestion.sp_modificar_Unidad_Funcional @id = 1,@id_consorcio = 4,@piso = 'PB',
@depto = 'A',@porcentaje = 1,@superficie_m2 = 2,@tiene_cochera =1,@tiene_baulera = 0;
--no

EXEC gestion.sp_importar_pagos
     @path = N'C:\Consorcios\pagos_consorcios.csv'; 
--no

EXEC gestion.sp_reporte_recaudacion_por_procedencia 
@anioInicio = 2025, @anioFin = 2025, @idConsorcio = 1;
--si

EXEC gestion.sp_reporte_mayores_ingresos_gastos_xml
@id_consorcio = NULL, @anio_inicio = 2025, @anio_fin = 2025;
--si

EXEC gestion.sp_reporte_top_morosos 
--si---- Consulta: este reporte usa API

EXEC gestion.sp_modificar_Consorcio 
@id = 999, @nombre = 'Consorcio Editado', @calle = 'Belgrano', @nro = 250, @localidad = 'Mor�n', @provincia = 'Buenos Aires';
--no