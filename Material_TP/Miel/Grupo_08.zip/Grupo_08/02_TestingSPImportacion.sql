/*
- Materia: Bases de Datos Aplicadas

- Comisi�n: 02-5600 - Viernes Tarde

- Fecha: 7/11/2025

- Grupo: 8

- Integrantes:
Cazal, Leila Abigail - 42023980
Fanton, Sol Bel�n - 38789602
Castro, Ezequiel Alejandro - 45239803
Grance Zenteno, Lucas Rodrigo - 43406784

- Enunciado:

*** Entrega 5 ***
(...)
El c�digo fuente no debe incluir referencias hardcodeadas a nombres o ubicaciones de archivo. Esto debe permitirse ser provisto por par�metro en la invocaci�n. En el c�digo de ejemplo se ver� d�nde el grupo decidi� ubicar los archivos, pero si cambia el entorno de ejecuci�n deber�a adaptarse sin modificar el fuente (s� obviamente el script de testing).
(...)

En este archivo, se encuentran los scripts para realizar la ejecuci�n de los SPs de importaci�n antes generados.
La ruta de los archivos, que se recibe por par�metro en cada SP, se DEBE cambiar por la correspondiente a la ubicaci�n de los archivos en su PC.

*/
use Com5600G08
go

----------------------------------------------------

--- Cargamos tablas con datos ---

/*
Para sus pruebas en local, deben reemplazar las rutas a los archivos por las de sus computadoras
*/

----------------------------------------------------

-- Tipo_Documento
EXEC gestion.sp_importar_tipos_documentos;

-- Consorcio
EXEC gestion.sp_importar_consorcios
     @pathConsorcios = N'C:\consorcios\datos-varios-consorcios.csv';

-- Unidad_Funcional
EXEC gestion.sp_importar_unidades_funcionales
     @path = N'C:\consorcios\UF por consorcio.txt'

-- Persona
-- Unidad_Funcional_Persona
-- Cuenta_Bancaria_Asociada_UF
EXEC gestion.sp_importar_personas
     @pathPersonasDatos = N'C:\consorcios\Inquilino-propietarios-datos.csv',
     @pathPersonasUF = N'C:\consorcios\Inquilino-propietarios-UF.csv';

-- Pago
EXEC gestion.sp_importar_pagos
     @path = N'C:\consorcios\pagos_consorcios.csv';

-- Tipos gastos ordinarios y proveedores
EXEC gestion.sp_importar_tipos_gastos_y_proveedores
     @path =  N'C:\consorcios\datos-varios-proveedores.csv',
    @rowTerminator = '\r';

-- Tipos gastos extraordinarios y proveedores
EXEC gestion.sp_importar_tipos_gastos_y_proveedores
     @path =  N'C:\consorcios\extraordinario.csv', @extraordinarios = 1;

-- Gastos ordinarios
DECLARE @json NVARCHAR(MAX)
SELECT @json = BulkColumn FROM OPENROWSET(BULK 'C:\consorcios\Servicios.Servicios.json', SINGLE_CLOB) AS jsonn
--print(@json)
exec gestion.sp_importar_gastos_ordinarios_anio_actual @jsonData = @json

-- Gastos extraordinarios
DECLARE @json2 NVARCHAR(MAX)
SELECT @json2 = BulkColumn FROM OPENROWSET(BULK 'C:\consorcios\Servicios.ServiciosExtraordinariosv2.json', SINGLE_CLOB) AS jsonn
--print(@json2)
exec gestion.sp_importar_gastos_extraordinarios_anio_actual @jsonData = @json2

-- Expensa
declare @id_consorcio int = 1
declare @mes tinyint = 4
declare @anio smallint = 2025

while @id_consorcio <= 5
begin
    declare @m tinyint = @mes;
    
    while @m <= 6
    begin
        print concat('Ejecutando sp_generar_expensa para consorcio ', @id_consorcio, ', mes ', @m, ', a�o ', @anio)

        exec gestion.sp_generar_expensa
            @id_consorcio = @id_consorcio,
            @mes = @m,
            @anio = @anio

        set @m += 1
    end

    set @id_consorcio += 1
end
go

-- Prorrateo
declare @id_consorcio int = 1
declare @mes tinyint = 4
declare @anio smallint = 2025

while @id_consorcio <= 5
begin
    declare @m tinyint = @mes;
    
    while @m <= 6
    begin
        print concat('Ejecutando sp_generar_prorrateo para consorcio ', @id_consorcio, ', mes ', @m, ', a�o ', @anio)

        exec gestion.sp_generar_prorrateo
            @id_consorcio = @id_consorcio,
            @mes = @m,
            @anio = @anio

        set @m += 1
    end

    set @id_consorcio += 1
end
go

--tablas
/*select* from Com5600G08.gestion.Tipo_Documento
select* from Com5600G08.gestion.Consorcio
select* from Com5600G08.gestion.Gasto
select* from Com5600G08.gestion.Persona
select* from Com5600G08.gestion.Proveedor
select* from Com5600G08.gestion.Tipo_Gasto
select * from Com5600G08.gestion.Unidad_Funcional
select* from Com5600G08.gestion.Unidad_Funcional_Persona
select* from Com5600G08.gestion.Cuenta_Bancaria_Asociada_UF
select top 20* from Com5600G08.gestion.Pago
select * from Com5600G08.gestion.Prorrateo
select top 20* from Com5600G08.gestion.Expensa*/

